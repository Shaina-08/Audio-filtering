

%Designing 2nd order low pass Butterworth filter using bilinear transformation. The practical response of Second Order Low Pass Butterworth Filter must be very close to an ideal one.

% Load recorded audio file
[data, Fs] = audioread('HearwithShaina.wav');


% Design Butterworth filter
% Get filter parameters from user input

fc = input('Enter cutoff frequency (in Hz): ');




% Calculate filter coefficients
% Pre-warping the cutoff frequency
wc = 2 * pi * fc / Fs; % Cutoff frequency in radians per second
T = 1/Fs;
% Pre-warping the cutoff frequency
wp = tan(wc*T/2)*2/Fs;

% Generate the transfer function
s = tf('s');
q = sqrt(2);
%The constant q is the damping factor, which is used to ensure that the filter response is maximally flat at the cutoff frequency.
h = s/wp;
Hs = 1 / (h^2 + q*h + 1);


k = 1 / tan(wc/2);
%This coefficient is used to calculate the filter coefficients from the cutoff frequency

a0 = 1 + k/q + k^2;
%This coefficient is the gain factor of the filter.It scales the output of the filter to match the input signal amplitude.
a1 = 2 * (k^2 - 1) / a0;
a2 = 1 - k/q + k^2 / a0;
%These coefficients are the feedback coefficients in the filter transfer function. They determine the filter's pole locations and influence its frequency response. 
b1 = 2 * (k^2 - 1) / a0;
b2 = (1 - k/q + k^2) / a0;%These coefficients are the feedforward coefficients in the filter transfer function. 


% Apply filter to data extracted from audio
filtered_data = zeros(size(data));
%The output of the filter will be  stored in filtered_data, which is initialized as a matrix of zeros with the same size as data.



for n = 3:length(data)
    filtered_data(n) = (1/a0) * (data(n) + a1*data(n-1) + a2*data(n-2) - b1*filtered_data(n-1) - b2*filtered_data(n-2));
end
%The loop is designed to iterate through each element of the input signal data starting from the third element. This is because the filter implementation used in the loop requires two previous values of the input signal data (i.e., data(n-1) and data(n-2)), so it cannot be applied to the first two elements of data.
%By starting the loop at n = 3, the filter can be applied to every element of data for which there are at least two previous elements available. Therefore, the first two elements of filtered_data will be set to zero, since they cannot be calculated using the filter equation.


% Save filtered audio to new file and name the file as filteraudio.wav
audiowrite('filteredaudio.wav', filtered_data, Fs);
% Load filtered audio file 
[filtered_data, Fs] = audioread('filteredaudio.wav');


X = filtered_data;
t = 0:1/Fs:(length(X)-1)/Fs;
subplot(2,1,1); 
plot(t,X,'LineWidth' ,1.5);
xlabel('time(sec)'); 
ylabel('Amplitude');
title('Time Domain plot of the Filtered Signal');
n = length(X); 
F = 0:(n-1)*Fs/n;

Y = fft(filtered_data,n);
F_0 = (-n/2:n/2-1).*(Fs/n);
Y_0 = fftshift(Y);
AY_0 = abs(Y_0);
subplot(2,1,2); 
plot(F_0,AY_0,'LineWidth',1.5);
xlabel('Frequency (Hz)');
ylabel('Amplitude');
title('Frequency Domain plot of Filtered Audio Signal ');



% Play filtered audio

% use this to play filtered audi "soundsc(filtered_data, Fs)";









