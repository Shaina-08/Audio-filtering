Fs = 44100; Channels = 1; bits = 16;
r = audiorecorder(Fs,bits, Channels);
duration = 5; 
disp('Please Say Something');
recordblocking(r,duration);
disp('Thank You');
X = getaudiodata(r);
t = 0:1/Fs:(length(X)-1)/Fs;
subplot(2,1,1); 
plot(t,X,'LineWidth' ,1.5);
xlabel('time(sec)'); 
ylabel('Amplitude');
title('Time Domain plot of the Recorded Signal');
n = length(X); 
F = 0:(n-1)*Fs/n;
Y = fft(X,n);
F_0 = (-n/2:n/2-1).*(Fs/n);
Y_0 = fftshift(Y);
AY_0 = abs(Y_0);
subplot(2,1,2); 
plot(F_0,AY_0,'LineWidth',1.5);
xlabel('Frequency (Hz)');
ylabel('Amplitude');
title('Frequency Domain plot of Audio Signal ');
filename = 'HearwithShaina.wav';
audiowrite(filename,X,Fs);
%sound(X,Fs,bits);


